from django.urls import path
from . import views
from .views import homepage
from .views import about

# /products

urlpatterns = [
    path('', homepage),
    path('about', about),
    path('accounts/about', about),
]

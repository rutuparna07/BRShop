from django.shortcuts import render, redirect, get_object_or_404, HttpResponseRedirect
from django.urls import reverse
from django.db import models
from .models import Cart
from shop.models import Product

def view(request):
    cart = Cart.objects.all()[0]
    return render(request, "cart.html", {'cart': cart})

def update_cart(request, slug):
    cart = Cart.objects.all()[0]
    try:
        product = Product.objects.get(slug=slug)
    except Product.DoesNotExist:
        pass

    if  product not in cart.product.all():
        cart.product.add(product)
        new_total= 0
        for item in cart.product.all():
            new_total += item.price
        cart.total=new_total
        cart.save()
    return redirect("/shop/")

def remove(request, slug):
    cart = Cart.objects.all()[0]
    try:
        product = Product.objects.get(slug=slug)
    except Product.DoesNotExist:
        pass

    if product in cart.product.all():
        cart.product.remove(product)
    cart.total -= product.price
    cart.save()
    return render(request, "cart.html", {'cart': cart})


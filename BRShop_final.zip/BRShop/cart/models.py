from django.db import models
from shop.models import Product

class Cart(models.Model):
    product = models.ManyToManyField(Product,null=True, blank=True)
    total = models.DecimalField(max_digits=10, decimal_places=2)
    available = models.BooleanField(default=True)













'''
class OrderItem(models.Model):
    #ordered = models.BooleanField(default=False)
    item = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)

    def __str__(self):
        return f"{self.quantity} of {self.item.title}"

    def get_total_item_price(self):
        return self.quantity * self.item.price

class Order(models.Model):
    items = models.ManyToManyField(OrderItem)
    ordered = models.BooleanField(default=False)

    def get_total(self):
        total = 0
        for order_item in self.items.all():
            total += order_item.get_final_price()
        return total
'''
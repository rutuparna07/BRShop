from django.urls import path
from . import views

app_name = 'cart'
urlpatterns = [
    path('', views.view, name='cart'),
    path('update_cart/<slug:slug>', views.update_cart, name='update_cart'),
    path('remove/<slug:slug>/', views.remove, name='remove'),
]

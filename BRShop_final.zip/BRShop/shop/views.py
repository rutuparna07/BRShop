from django.shortcuts import render
from .models import Category, Product


def index(request):
    product = Product.objects.all()
    categories = Category.objects.all()
    return render(request, 'index.html', {'product': product, 'categories': categories})
